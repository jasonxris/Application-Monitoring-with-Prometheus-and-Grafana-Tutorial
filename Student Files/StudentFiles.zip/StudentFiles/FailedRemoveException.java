public class FailedRemoveException extends Exception {
    public FailedRemoveException(String message) {
        super(message);
    }
}
